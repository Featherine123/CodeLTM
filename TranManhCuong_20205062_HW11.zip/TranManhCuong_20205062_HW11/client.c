#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/wait.h>
#include <pthread.h>

#define SERV_PORT 5550
#define SERV_IP "127.0.0.1"
#define BUFF_SIZE 256

size_t bytes_sent, bytes_received;
int isLogined = 0;
int khoaDoiXung = 3;
size_t msg_len;

struct ThreadData {
    int client_sock;
    pthread_mutex_t mutex;
};

int checkValid(const char *input) {
    for (int i = 0; input[i] != '\0'; i++) {
        if (!isalnum(input[i])) {
            return 0;
        }
    }
    return 1;
}

void *receiveThread(void *arg) {
    struct ThreadData *threadData = (struct ThreadData *)arg;
    int client_sock = threadData->client_sock;
    char buff[BUFF_SIZE];
    while (1) {
        memset(buff, 0, sizeof(buff));
        bytes_received = recv(client_sock, buff, sizeof(buff) - 1, 0);

        if (bytes_received < 0) {
            perror("Lỗi khi nhận dữ liệu từ server: ");
            break;
        } else if (bytes_received == 0) {
            // Kết nối đã đóng bởi server
            break;
        }

        // Bảo vệ các tác vụ sử dụng mutex
        pthread_mutex_lock(&threadData->mutex);
        //unsigned char decrypted_message[BUFF_SIZE];
        //rc4_decrypt(buff, bytes_received, key, decrypted_message);
        //decrypted_message[strlen(decrypted_message)] = '\0';

        // Sử dụng một biến tạm để lưu trữ tin nhắn
        char temp_message[BUFF_SIZE];
        snprintf(temp_message, sizeof(temp_message), "%s", buff);

        printf("%s\n", temp_message);
        pthread_mutex_unlock(&threadData->mutex);
    }

    close(client_sock);
    pthread_exit(NULL);
}


int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Sử dụng:  ./client IPAddress PortNumber\n");
        return 1;
    }

    char *ip = argv[1];
    char *port = argv[2];
    int port_number = atoi(port);

    int client_sock;
    char buff[BUFF_SIZE];
    struct sockaddr_in server_addr;

    client_sock = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);
    server_addr.sin_addr.s_addr = inet_addr(ip);

    if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0) {
        printf("\nLỗi! Không thể kết nối đến server! Chương trình client sẽ thoát ngay bây giờ! ");
        return 0;
    }
    printf("if not request Username from Server please send 'login'\n");
    pthread_t tid;
    struct ThreadData threadData;
    threadData.client_sock = client_sock;
    pthread_mutex_init(&threadData.mutex, NULL);

    // Tạo một thread mới để nhận dữ liệu từ server
    if (pthread_create(&tid, NULL, receiveThread, (void *)&threadData) != 0) {
        perror("Lỗi khi tạo thread");
        close(client_sock);
        pthread_mutex_destroy(&threadData.mutex);
        return 0;
    }

    do {
    fgets(buff, BUFF_SIZE, stdin);
    //unsigned char ciphertext[BUFF_SIZE];
    if (strcmp(buff, "\0") == 0) {
        break;
    }
    buff[strlen(buff) - 1] = '\0';

    // Sử dụng một biến tạm để lưu trữ dữ liệu gửi đi
    char temp_message[BUFF_SIZE];
    snprintf(temp_message, sizeof(temp_message), "%s", buff);

    //rc4_encrypt(temp_message, strlen(temp_message), key, ciphertext);

    // Bảo vệ các tác vụ sử dụng mutex
    pthread_mutex_lock(&threadData.mutex);
    // Gửi dữ liệu đến server
    bytes_sent = send(client_sock, temp_message, strlen(temp_message), 0);
    if(strcmp(temp_message, "2") == 0){
            
            FILE* image = fopen("image.jpeg", "rb");
            size_t bytes_read, bytes_sent;
            while ((bytes_read = fread(buff, 1, sizeof(buff), image)) >= 0) {
                if(bytes_read < sizeof(buff)){
                    bytes_sent = send(client_sock, buff, bytes_read, 0);
                    break;  
                }
                bytes_sent = send(client_sock, buff, bytes_read, 0);
                if (bytes_sent < 0) {
                    perror("Lỗi khi gửi dữ liệu");
                    break;
                }
                // bytes_received = recv(client_sock, buff, BUFF_SIZE-1, 0);
                // if(bytes_received <= 0){
                //     printf("\nError!Cannot receive data from sever!\n");
                //     break;
                // }
                // buff[bytes_received] = '\0';
                // printf("%s", buff);
            }
            fclose(image);
            char* end = "End";
            bytes_sent = send(client_sock, end, bytes_read, 0);
            printf("%ld\n", bytes_sent);
    }
    
    pthread_mutex_unlock(&threadData.mutex);

    if (bytes_sent < 0) {
        perror("Lỗi khi gửi dữ liệu đến server: ");
        break;
    }
} while (strcmp(buff, "\0") != 0);

    close(client_sock);
    pthread_cancel(tid);  // Hủy thread nhận dữ liệu từ server khi kết thúc chương trình client
    pthread_mutex_destroy(&threadData.mutex);

    return 0;
}
